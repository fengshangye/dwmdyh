#!/bin/bash

setxkbmap us colemak -option -option caps:swapescape -option ctrl:swap_lalt_lctl -option lv3:ralt_alt
#xmodmap ~/.config/.Xmodmap
xset r rate 250 30

