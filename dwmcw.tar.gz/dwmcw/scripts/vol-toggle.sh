#!/bin/bash

/usr/bin/amixer set Master toggle
bash ~/scripts/dwm-status-refresh.sh
