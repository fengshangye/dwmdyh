#!/bin/bash

sleep 10
#xmodmap ~/.Xmodmap &
#fcitx &
