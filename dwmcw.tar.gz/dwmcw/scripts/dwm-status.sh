#!/bin/bash

while true
do
	bash ./dwm-status-refresh.sh
	sleep 2
done
