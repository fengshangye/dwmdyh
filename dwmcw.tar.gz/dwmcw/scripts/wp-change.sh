#!/bin/bash

feh --recursive --randomize --bg-fill ~/Pictures/wallpapers/ghibili
#feh --recursive --randomize --bg-fill ~/Pictures/wallpapers/view
