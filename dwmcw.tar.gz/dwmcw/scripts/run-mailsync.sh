#!/bin/bash

while :; do
	mailsync
	sleep 300
done
