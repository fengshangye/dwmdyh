#!/bin/bash

xmodmap ~/.Xmodmap-cn
xset r rate 250 30

