#!/bin/bash

while true; do
	/bin/bash ~/scripts/wp-change.sh
	sleep 3m
done
