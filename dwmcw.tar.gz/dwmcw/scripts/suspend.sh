#!/bin/bash

systemctl suspend
