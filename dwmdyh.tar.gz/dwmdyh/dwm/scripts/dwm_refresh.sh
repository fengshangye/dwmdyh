#!/bin/bash

while true
do
	/bin/bash ~/scripts/dwmstatusprint.sh
	sleep 1
done
